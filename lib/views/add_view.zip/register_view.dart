import 'package:flutter/material.dart';
import 'package:demo/views/login_view.dart';

void main() => runApp(RegistrationApp());

class RegistrationApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Registration Page',
      home: RegistrationPage(),
    );
  }
}

class RegistrationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registration Page'),
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child: RegistrationForm(),
      ),
    );
  }
}

class RegistrationForm extends StatefulWidget {
  @override
  _RegistrationFormState createState() => _RegistrationFormState();
}

class _RegistrationFormState extends State<RegistrationForm> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _codeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          _buildTextFieldWithLabel('Name', _nameController),
          SizedBox(height: 16.0),
          _buildTextFieldWithLabel('Email', _emailController),
          SizedBox(height: 16.0),
          _buildTextFieldWithLabel('Password', _passwordController,
              obscureText: true),
          SizedBox(height: 16.0),
          _buildTextFieldWithLabel('Verification Code', _codeController),
          SizedBox(height: 24.0),
          ElevatedButton(
            onPressed: () {
              // Perform registration logic here
              String name = _nameController.text;
              String email = _emailController.text;
              String password = _passwordController.text;
              String code = _codeController.text;

              // Example registration validation
              if (name.isNotEmpty &&
                  email.isNotEmpty &&
                  password.isNotEmpty &&
                  code.isNotEmpty) {
                // Successful registration, show a success message
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Registration Successful'),
                      content: Text(
                          'Congratulations, $name! You have been registered.'),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              } else {
                // Show an error message
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Please fill in all fields')),
                );
              }
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LoginApp()),
              );
            },
            style: ElevatedButton.styleFrom(primary: Colors.purple),
            child: Text('Sign Up'),
          ),
          SizedBox(height: 8.0),
          TextButton(
            onPressed: () {
              // Navigate to the login page
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LoginApp()),
              );
            },
            style: TextButton.styleFrom(primary: Colors.purple),
            child: Text('Sign In'),
          ),
        ],
      ),
    );
  }

  Widget _buildTextFieldWithLabel(
      String label, TextEditingController controller,
      {bool obscureText = false, double height = 60.0}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(height: 6.0),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 10.0),
          height: height,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(
              color: Colors.black,
              width: 2.0,
            ),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscureText,
            decoration: InputDecoration(
              hintText: label,
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login Page'),
      ),
      body: Center(
        child: Text('Sign in here'),
      ),
    );
  }
}
