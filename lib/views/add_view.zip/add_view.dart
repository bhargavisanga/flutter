import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Regulation and Subjects',
      theme: ThemeData(primarySwatch: Colors.purple),
      home: RegulationAndSubjectsScreen(),
    );
  }
}

class RegulationAndSubjectsScreen extends StatefulWidget {
  @override
  _RegulationAndSubjectsScreenState createState() =>
      _RegulationAndSubjectsScreenState();
}

class _RegulationAndSubjectsScreenState
    extends State<RegulationAndSubjectsScreen> {
  String selectedRegulation = '';
  String selectedBranch = '';
  String selectedSubject = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Regulation and Subjects'),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage(
              'https://image.shutterstock.com/image-vector/abstract-backgroundvector-illustration-260nw-665629954.jpg', // Replace with the actual image URL
            ),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20), // Add space for the image
              Text(
                'Regulation',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextField(
                onChanged: (newValue) {
                  setState(() {
                    selectedRegulation = newValue;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Enter Regulation',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Branch',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextField(
                onChanged: (newValue) {
                  setState(() {
                    selectedBranch = newValue;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Enter Branch',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Subject',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextField(
                onChanged: (newValue) {
                  setState(() {
                    selectedSubject = newValue;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Enter Subject',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // You can perform actions using the selected data
                  print('Selected Regulation: $selectedRegulation');
                  print('Selected Branch: $selectedBranch');
                  print('Selected Subject: $selectedSubject');
                },
                child: Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
