import 'package:flutter/material.dart';
import 'package:demo/views/register_view.dart';
import 'package:demo/views/admintwo_view.dart';
//import 'package:demo/views/search_view.dart';
final 
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'User Selection',
      theme: ThemeData(primarySwatch: Colors.purple),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
          centerTitle: true, // Add this line to center the title

      ),
      body: Container(
        decoration: BoxDecoration(
          image:DecorationImage(
            image:NetworkImage(
              'https://image.shutterstock.com/image-vector/abstract-backgroundvector-illustration-260nw-665629954.jpg'),
              fit:BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 10,),
              Image.asset(
                'assets/b1.png',
                width: 50,
                height: 50,
              ),
              SizedBox(height: 10,),
              ElevatedButton(
                onPressed: () {
                  // Code for Admin Button
                  Navigator.push(context, MaterialPageRoute(builder: (context) => LoginApp()),);
                },
                child: Text('Admin'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  // Code for Faculty Button
Navigator.push(context, MaterialPageRoute(builder: (context) => RegistrationApp()),);

                },
                child: Text('Faculty'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  // Code for Student Button
 //Navigator.push(context, MaterialPageRoute(builder: (context) => MyAppss()),);
                },
                child: Text('Student'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
