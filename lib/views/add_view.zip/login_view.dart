import 'package:flutter/material.dart';
import 'drop_view.dart';
void main() => runApp(LoginApp());

class LoginApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login Page',
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login Page'),
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child: LoginForm(),
      ),
    );
  }
}

class LoginForm extends StatefulWidget {
  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(height: 20.0), // Add space at the top
          Container(
            width: MediaQuery.of(context).size.width * 0.4,
            height: MediaQuery.of(context).size.width * 0.4,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.black, // Replace with the desired border color
                width: 2.0, // Replace with the desired border width
              ),
            ),
            child: CircleAvatar(
              backgroundColor: Colors.transparent,
              backgroundImage: NetworkImage(
                  'https://www.shutterstock.com/image-vector/isolated-abstract-black-color-education-260nw-691338460.jpg'),
              // Replace with your image asset
            ),
          ),

          SizedBox(height: 50.0), // Reduce space between avatar and text fields
          Container(
            padding: EdgeInsets.all(10.0), // Add padding around the container
            height: 60.0, // Reduced height for the email box frame
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0), // Add rounded corners
              border: Border.all(
                color: Colors.black, // Replace with the desired border color
                width: 2.0, // Replace with the desired border width
              ),
            ),
            child: TextField(
              controller: _emailController,
              decoration: InputDecoration(
                hintText: 'Email', // Use placeholder as hint
                border: InputBorder.none, // Remove the default border
              ),
            ),
          ),

          SizedBox(
              height: 10.0), // Reduce space between email and password fields
          Container(
            padding: EdgeInsets.all(10.0), // Add padding around the container
            height: 60.0, // Reduced height for the password box frame
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10.0), // Add rounded corners
              border: Border.all(
                color: Colors.black, // Replace with the desired border color
                width: 2.0, // Replace with the desired border width
              ),
            ),
            child: TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Password', // Use placeholder as hint
                border: InputBorder.none, // Remove the default border
              ),
            ),
          ),

          SizedBox(height: 20.0), // Maintain space below text fields
          ElevatedButton(
            onPressed: () {
              // Perform login logic here
              String email = _emailController.text;
              String password = _passwordController.text;

              // Example login validation
              if (email == 'user@example.com' && password == 'password') {
                // Successful login, navigate to the next page
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => MyApp()),
                );
              } else {
                // Show an error message
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Invalid email or password')),
                );
              }
            Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyApp()),
                );  
            },
            child: Text('Login'),
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
      ),
      body: Center(
        child: Text('Welcome to the Home Page!'),
      ),
    );
  }
}